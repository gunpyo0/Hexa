using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manager : MonoBehaviour
{
    public static Manager instance;
    public int[,] map = new int[10, 20];
    public bool[,] isSpawned = new bool[10, 20];
    public bool canSpawn = false;
    public int[] canSpace = {18,18,18,18,18,18,18,18,18,18};
    public GameObject[] wcObj;
    public int wObj;
    Main main;

    // Start is called before the first frame update
    void Awake()
    {
        if (instance == null)
            instance = this;
    }

    private void Start()
    {
        main = Main.instance.GetComponent<Main>();
    }

    // Update is called once per frame
    void Update()
    {
        Spawn();
    }
    void Spawn()
    {
        if (canSpawn)
        {
            Vector2 spawnPos = new Vector2(5, 18);
            wObj = Random.Range(wcObj.Length - 1, 0);
            Instantiate(wcObj[wObj], spawnPos, Quaternion.identity);
            canSpawn = false;
        }
        /*if (isSpawned[main.x, main.y])
        {
            canSpawn = false;
        }
        if (canSpawn)
        {
            Vector2 spawnPos = new Vector2(5, 18);
            wObj = Random.Range(wcObj.Length, 0);
            Instantiate(wcObj[wObj], spawnPos, Quaternion.identity);
            canSpawn 
        }*/
        
    }
}
