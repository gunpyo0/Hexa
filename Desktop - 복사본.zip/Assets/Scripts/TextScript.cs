using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TextScript : MonoBehaviour
{
    public Text text;
    Main main;
    int score = 1;

    // Start is called before the first frame update
    void Start()
    {
        main = Main.instance.GetComponent<Main>();
    }

    // Update is called once per frame
    void Update()
    {
        if (main.canText)
        {
            text.text = "����: " + score;
        }
    }

    
}
