using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Main : MonoBehaviour
{
    public static Main instance;
    public int x, y, i = 1, whatColor, v;
    Manager manager;
    public bool canMove = true;
    public float delay;
    public bool isSpawned = false;
    public bool specialSpawn = false;
    public bool canText = false;
    public bool specialDown = false;

    void Awake()
    {
        if (instance == null)
            instance = this;
    }

    void Start()
    {
        manager = Manager.instance.GetComponent<Manager>();
    }

    void Update()
    {
        Move();
        Check();
    }

    int WhichColor(int a)
    {
        switch(gameObject.tag)
        {
            case "Blue": a = 1; break;
            case "Green": a = 2; break;
            case "Red": a = 3; break;
            default: a = 0; break;
        }
        return a;
    }

    void Move()
    {
        whatColor = WhichColor(whatColor);

        x = Mathf.RoundToInt(transform.position.x); // ������Ʈ�� x���� �ݿø��Ͽ� ���� x�� ������
        y = Mathf.RoundToInt(transform.position.y); // y�� �ݿø� y�� ����
        delay += Time.deltaTime; // �����̿� �ð��� �Լ� ���Ͽ� ��������
        if (!canMove && manager.map[x,y] == 0)
        {
            Destroy(gameObject);
            canText = true;
            specialSpawn = true;
            specialDown = true;
        }
        if (!specialDown && y == 0 && manager.map[x, y] == 0 && !specialSpawn) // ������Ʈ�� �ǾƷ���
        {
            i = 0; // �Ʒ����ִ� ���ǹ� �迭�� ũ�⸦ ����� �ʱ����� y�� 0�϶� i�� 0���� ����
            canMove = false; // �ǾƷ��� ������Ʈ�� ��ġ�ƴٴ°ű⿡ canMove�� false�� ����� �������̰� ��
            manager.map[x, y] = whatColor;
            manager.canSpawn = true;
            manager.isSpawned[x, y] = true;
            /*Vector2 spawnPos = new Vector2(5, 18);
            manager.wObj = Random.Range(manager.wcObj.Length-1, 0);
            Instantiate(manager.wcObj[manager.wObj], spawnPos, Quaternion.identity);*/
            //Debug.Log(manager.map[x, y]);
        }
        if (!specialDown && manager.map[x, y - i] != 0 && manager.map[x, y] == 0 && !specialSpawn) // ������Ʈ �Ʒ��� ��ġ���ִ� ������Ʈ�� ������
        {
            canMove = false; // ��ġ���ִ� ������Ʈ���� ��ġ��(�������̰���)
            manager.map[x, y] = whatColor;
            manager.canSpawn = true;
            manager.isSpawned[x, y] = true;
            specialDown = true;
            /*Vector2 spawnPos = new Vector2(5, 18);
            manager.wObj = Random.Range(manager.wcObj.Length -1, 0);
            Instantiate(manager.wcObj[manager.wObj], spawnPos, Quaternion.identity);*/
            i = 1;
            
            Debug.Log(manager.map[x, y]);
        }
        if(specialSpawn)
        {
            
            specialSpawn = false;
        }
        if(!canMove && y != 0 && manager.map[x,y-1] == 0)
        {
            manager.map[x, y] = 0;
            transform.position = new Vector2(x, y - 1);
            manager.map[x, y - 1] = whatColor;
            
            
            
        }
        if (x == 9)
        {
            v = 0;
        } else if(x == 0)
        {
            v = 0;
        }
        if(Input.GetKeyDown(KeyCode.RightArrow) && canMove && manager.map[x + v, y] == 0 && x != 9)
        {
            transform.position = new Vector2(x + 1, y);
            v = 1;
        } else if(Input.GetKeyDown(KeyCode.LeftArrow) && canMove && manager.map[x - v, y] == 0 && x != 0)
        {
            transform.position = new Vector2(x - 1, y);
            v = 1;
        }
        /*if(Input.GetKeyDown(KeyCode.Space) && canMove*//* && manager.map[x, y - manager.canSpace[x]] == 0*//*)
        {
            transform.position = new Vector2(x, y - manager.canSpace[x]);
            canMove = false;
            manager.map[x, y] = whatColor;
            manager.canSpawn = true;
            manager.isSpawned[x, y] = true;
            specialDown = true;
            manager.canSpace[x] -= 1;
        }*/
        if(delay >= 0.5 && canMove) // 1�ʰ� �������� ������Ʈ�� �����ϼ�������
        {
            transform.position = new Vector2(x, y - 1); // ������Ʈ�� ��ĭ �Ʒ��� �̵���Ŵ
            delay = 0; // ���� ���ǹ��� 1�ʰ� �������� ������ 1�ʰ� ���������� �����̸� 0�ʷ� �ʱ�ȭ������
            //manager.canSpace[x] -= 1;
        }
        /*if(!canMove && !manager.isSpawned[x, y]) // �������̰� ������Ʈ�� �������� �ʾ�����
        {
            canMove = true; // ������Ʈ�� �����̰��� (��������)
        }*/
        
    }

    void Check()
    {
        

        for(int w = 0; w < 9; w++)
        {
            for(int h = 0; h < 17; h++)
            {
                if (manager.map[w, h] * manager.map[w, h+1] * manager.map[w, h+2] == 1 || manager.map[w, h] * manager.map[w, h + 1] * manager.map[w, h + 2] == 8 
                    || manager.map[w, h] * manager.map[w, h + 1] * manager.map[w, h + 2] == 27)
                {
                    manager.map[w, h] = 0;
                    manager.map[w, h + 1] = 0;
                    manager.map[w, h + 2] = 0;
                    manager.canSpace[w] -= 3;
                }
            }
        }
        for(int h = 0; h < 19; h++)
        {
            for(int w = 0; w < 8; w++)
            {
                if (manager.map[w, h] * manager.map[w + 1, h] * manager.map[w + 2, h] == 1 || manager.map[w, h] * manager.map[w + 1, h] * manager.map[w + 2, h] == 8
                    || manager.map[w, h] * manager.map[w + 1, h] * manager.map[w + 2, h] == 27)
                {
                    manager.map[w, h] = 0;
                    manager.map[w + 1, h] = 0;
                    manager.map[w + 2, h] = 0;
                    manager.canSpace[w] -= 3;
                }
            }
        }
        for(int h = 0; h < 17; h++)
        {
            for(int w = 0; w < 9; w++)
            {
                if(w < 9)
                {
                    if (manager.map[w, h] * manager.map[w + 1, h + 1] * manager.map[w + 2, h + 2] == 1 || manager.map[w, h] * manager.map[w + 1, h + 1] * manager.map[w + 2, h + 2] == 8 ||
                    manager.map[w, h] * manager.map[w + 1, h + 1] * manager.map[w + 2, h + 2] == 27)
                    {
                        manager.map[w, h] = 0;
                        manager.map[w + 1, h + 1] = 0;
                        manager.map[w + 2, h + 2] = 0;
                    }
                }
                
                if(w >= 2)
                {
                    Debug.Log(w);
                    if (manager.map[w, h] * manager.map[w - 1, h + 1] * manager.map[w - 2, h + 2] == 1 || manager.map[w, h] * manager.map[w - 1, h + 1] * manager.map[w - 2, h + 2] == 8
                        || manager.map[w, h] * manager.map[w - 1, h + 1] * manager.map[w - 2, h - 2] == 27)
                    {
                        Debug.Log("aa");
                        manager.map[w, h] = 0;
                        manager.map[w - 1, h + 1] = 0;
                        manager.map[w - 2, h + 2] = 0;
                    }
                }
            }
            
        }
        /*for(int k = 0; k < 17; k++)
        {
            for (int j = 2; j < 9; j++)
            {
                
                    Debug.Log(j);
                    if (manager.map[j , k] * manager.map[j - 1, k + 1] * manager.map[j - 2, k + 2] == 1 || manager.map[j, k] * manager.map[j - 1, k + 1] * manager.map[j - 2, k + 2] == 8 
                        || manager.map[j, k] * manager.map[j - 1, k + 1] * manager.map[j - 2, k - 2] == 27)
                    {
                        Debug.Log("aa");
                        manager.map[j, k] = 0;
                        manager.map[j - 1, k + 1] = 0;
                        manager.map[j - 2, k + 2] = 0;
                    }

            }
        }*/
    }
}